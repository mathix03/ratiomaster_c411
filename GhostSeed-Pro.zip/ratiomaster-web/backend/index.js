const express = require('express');
const cors = require('cors');
const multer = require('multer');
const axios = require('axios');
const crypto = require('crypto');

const app = express();
app.use(cors());
app.use(express.json());

// In-memory store for active sessions
const activeSessions = new Map();

const storage = multer.memoryStorage();
const upload = multer({ 
  storage: storage,
  limits: { fileSize: 200 * 1024 * 1024 } // 200 MB limit
});

function generatePeerId(client = 'qBittorrent') {
  let prefix = '';
  if (client === 'qBittorrent') {
    prefix = '-qB4350-';
  } else if (client === 'Transmission') {
    prefix = '-TR3000-';
  } else {
    prefix = '-qB4350-'; // default
  }
  const randomStr = crypto.randomBytes(6).toString('hex');
  return prefix + randomStr;
}

function generateKey() {
  return crypto.randomBytes(4).toString('hex').toUpperCase();
}

app.post('/api/torrent/parse', upload.single('torrent'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No torrent file uploaded' });
    }
    
    const torrentData = req.file.buffer;
    const { default: parseTorrent } = await import('parse-torrent');
    const parsed = await parseTorrent(torrentData);
    
    const trackers = parsed.announce || [];
    if (trackers.length === 0) {
      return res.status(400).json({ error: 'No trackers found in torrent' });
    }

    res.json({
      name: parsed.name,
      infoHash: parsed.infoHash,
      length: parsed.length,
      trackers: trackers
    });
  } catch (error) {
    console.error('Error parsing torrent:', error);
    res.status(500).json({ error: 'Failed to parse torrent' });
  }
});

function createAnnounceUrl(trackerUrl, params) {
  const url = new URL(trackerUrl);
  Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
  return url.toString();
}

async function announce(session, event) {
  const { tracker, infoHash, peerId, port, uploaded, downloaded, left, key, client } = session;
  
  // Create URLSearchParams to handle proper encoding
  // InfoHash needs specific encoding (URL encoded binary string)
  const infoHashBuffer = Buffer.from(infoHash, 'hex');
  let infoHashStr = '';
  for (let i = 0; i < infoHashBuffer.length; i++) {
    const hex = infoHashBuffer[i].toString(16).toUpperCase();
    infoHashStr += '%' + (hex.length === 1 ? '0' + hex : hex);
  }

  const params = [
    `info_hash=${infoHashStr}`,
    `peer_id=${peerId}`,
    `port=${port}`,
    `uploaded=${uploaded}`,
    `downloaded=${downloaded}`,
    `left=${left}`,
    `corrupt=0`,
    `key=${key}`,
    `event=${event}`,
    `numwant=200`,
    `compact=1`,
    `no_peer_id=1`
  ];

  const fullUrl = `${tracker}${tracker.includes('?') ? '&' : '?'}${params.join('&')}`;

  let userAgent = 'qBittorrent/4.3.5';
  if (client === 'Transmission') userAgent = 'Transmission/3.00';

  try {
    const response = await axios.get(fullUrl, {
      headers: {
        'User-Agent': userAgent,
        'Accept-Encoding': 'gzip'
      },
      responseType: 'arraybuffer' // Tracker responses are often bencoded
    });
    
    // Parse bencoded response to extract leechers (incomplete) and seeders (complete)
    try {
      const { default: bencode } = await import('bencode');
      const decoded = bencode.decode(response.data);
      if (decoded.incomplete !== undefined) {
        session.leechers = decoded.incomplete;
      }
      if (decoded.complete !== undefined) {
        session.seeders = decoded.complete;
      }
    } catch (e) {
      console.error(`[${session.id}] Failed to decode tracker response:`, e.message);
    }
    
    console.log(`[${session.id}] Announce successful: ${event}`);
    return true;
  } catch (error) {
    console.error(`[${session.id}] Announce failed:`, error.message);
    return false;
  }
}

app.post('/api/session/start', async (req, res) => {
  const { infoHash, tracker, baseUploadSpeed, client = 'qBittorrent', stopAtSizeMB, stopAtTimeMins, name, useSequence, sequenceLoops, initialUploadedGB, initialDownloadedGB } = req.body;
  
  if (!infoHash || !tracker) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const sessionId = crypto.randomUUID();
  const session = {
    id: sessionId,
    name: name || 'Unknown Torrent',
    infoHash,
    tracker,
    client,
    peerId: generatePeerId(client),
    key: generateKey(),
    port: Math.floor(Math.random() * (65535 - 1024 + 1)) + 1024,
    uploaded: 0,
    downloaded: 0,
    left: 0, // spoofing a seed
    baseUploadSpeed: parseInt(baseUploadSpeed, 10) || 1024 * 1024, // bytes per second
    currentUploadSpeed: parseInt(baseUploadSpeed, 10) || 1024 * 1024,
    stopAtSize: stopAtSizeMB ? parseInt(stopAtSizeMB, 10) * 1024 * 1024 : null,
    stopAtTime: stopAtTimeMins ? parseInt(stopAtTimeMins, 10) * 60 * 1000 : null,
    useSequence: !!useSequence,
    sequenceLoops: parseInt(sequenceLoops, 10) || 1,
    initialUploadedGB: initialUploadedGB ? parseFloat(initialUploadedGB) : 0,
    initialDownloadedGB: initialDownloadedGB ? parseFloat(initialDownloadedGB) : 0,
    startTime: Date.now(),
    status: 'running',
    sequenceState: 'active', // 'active' or 'pause'
    lastAnnounce: Date.now(),
    nextAnnounce: Date.now() + 60000,
    leechers: -1,
    seeders: -1
  };

  activeSessions.set(sessionId, session);

  const SEQUENCE = [
    { type: 'active', duration: 4 },
    { type: 'pause', duration: 2 },
    { type: 'active', duration: 10 },
    { type: 'pause', duration: 4 },
    { type: 'active', duration: 15 },
    { type: 'pause', duration: 2 },
    { type: 'active', duration: 6 },
    { type: 'pause', duration: 1 }
  ];
  const totalSequenceDuration = SEQUENCE.reduce((acc, step) => acc + step.duration, 0) * 60 * 1000;

  // Send initial 'started' announce
  await announce(session, 'started');

  // Start interval for regular announces (e.g., every 60 seconds)
  const interval = setInterval(async () => {
    const currentSession = activeSessions.get(sessionId);
    if (!currentSession || currentSession.status !== 'running') {
      clearInterval(interval);
      return;
    }
    
    // Calculate uploaded since last announce
    const now = Date.now();
    const elapsedSeconds = (now - currentSession.lastAnnounce) / 1000;
    
    // Add uploaded data based on the PREVIOUS currentUploadSpeed
    currentSession.uploaded += Math.floor(elapsedSeconds * currentSession.currentUploadSpeed);
    currentSession.lastAnnounce = now;
    currentSession.nextAnnounce = now + 60000;
    
    let shouldStop = false;

    // Sequence Logic
    if (currentSession.leechers === 0) {
      currentSession.sequenceState = 'safety_pause';
      currentSession.currentUploadSpeed = 0;
      console.log(`[${sessionId}] Safety Pause: 0 Leechers detected.`);
    } else if (currentSession.useSequence) {
      const elapsedSinceStart = now - currentSession.startTime;
      const currentLoop = Math.floor(elapsedSinceStart / totalSequenceDuration);
      
      if (currentLoop >= currentSession.sequenceLoops) {
        shouldStop = true;
        console.log(`[${sessionId}] Auto-stopping: Sequence loops reached.`);
      } else {
        const timeInCurrentLoop = elapsedSinceStart % totalSequenceDuration;
        let accumulated = 0;
        let currentStep = SEQUENCE[0];
        for (const step of SEQUENCE) {
          accumulated += step.duration * 60 * 1000;
          if (timeInCurrentLoop < accumulated) {
            currentStep = step;
            break;
          }
        }
        currentSession.sequenceState = currentStep.type;
        
        if (currentStep.type === 'active') {
          const fluctuation = 1 + (Math.random() * 0.3 - 0.15); 
          currentSession.currentUploadSpeed = Math.floor(currentSession.baseUploadSpeed * fluctuation);
        } else {
          currentSession.currentUploadSpeed = 0;
        }
      }
    } else {
      // Normal fluctuation
      const fluctuation = 1 + (Math.random() * 0.3 - 0.15); 
      currentSession.currentUploadSpeed = Math.floor(currentSession.baseUploadSpeed * fluctuation);
      currentSession.sequenceState = 'active';
    }
    
    // Auto-stop logic (Size/Time)
    if (currentSession.stopAtSize && currentSession.uploaded >= currentSession.stopAtSize) {
      shouldStop = true;
      console.log(`[${sessionId}] Auto-stopping: Size limit reached.`);
    }
    if (currentSession.stopAtTime && (now - currentSession.startTime) >= currentSession.stopAtTime) {
      shouldStop = true;
      console.log(`[${sessionId}] Auto-stopping: Time limit reached.`);
    }
    
    if (shouldStop) {
      currentSession.status = 'stopped';
      currentSession.currentUploadSpeed = 0;
      clearInterval(interval);
      await announce(currentSession, 'stopped');
      return;
    }
    
    await announce(currentSession, '');
  }, 60000); 

  session.intervalId = interval;

  res.json({ sessionId, session: { ...session, intervalId: undefined } });
});

app.post('/api/session/stop', async (req, res) => {
  const { sessionId } = req.body;
  const session = activeSessions.get(sessionId);
  
  if (!session) {
    return res.status(404).json({ error: 'Session not found' });
  }

  session.status = 'stopped';
  clearInterval(session.intervalId);
  
  // Send 'stopped' announce
  await announce(session, 'stopped');
  activeSessions.delete(sessionId);

  res.json({ success: true });
});

app.post('/api/session/stop-all', async (req, res) => {
  const promises = [];
  for (const [sessionId, session] of activeSessions.entries()) {
    session.status = 'stopped';
    clearInterval(session.intervalId);
    promises.push(announce(session, 'stopped'));
  }
  
  await Promise.all(promises);
  activeSessions.clear();
  
  res.json({ success: true });
});

app.get('/api/session/status/:sessionId', (req, res) => {
  const session = activeSessions.get(req.params.sessionId);
  if (!session) {
    return res.status(404).json({ error: 'Session not found' });
  }
  
  // Live calculation of uploaded
  const now = Date.now();
  const elapsedSeconds = (now - session.lastAnnounce) / 1000;
  const liveUploaded = session.status === 'running' 
    ? session.uploaded + Math.floor(elapsedSeconds * session.currentUploadSpeed)
    : session.uploaded;
  const liveNextAnnounce = session.status === 'running' ? Math.max(0, session.nextAnnounce - now) : 0;

  res.json({
    ...session,
    uploaded: liveUploaded,
    nextAnnounceInMs: liveNextAnnounce,
    intervalId: undefined
  });
});

app.get('/api/sessions', (req, res) => {
  const now = Date.now();
  const sessionsList = Array.from(activeSessions.values()).map(session => {
    const elapsedSeconds = (now - session.lastAnnounce) / 1000;
    const liveUploaded = session.status === 'running' 
      ? session.uploaded + Math.floor(elapsedSeconds * session.currentUploadSpeed)
      : session.uploaded;
    const liveNextAnnounce = session.status === 'running' ? Math.max(0, session.nextAnnounce - now) : 0;
      
    return {
      ...session,
      uploaded: liveUploaded,
      nextAnnounceInMs: liveNextAnnounce,
      intervalId: undefined
    };
  });
  res.json(sessionsList);
});

const PORT = 3001;
app.listen(PORT, () => {
  console.log(`Backend server running on http://localhost:${PORT}`);
});
