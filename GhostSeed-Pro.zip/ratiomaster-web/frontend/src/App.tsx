import React, { useState, useRef, useEffect } from 'react';
import { Upload, Play, Square, Activity, Wifi, Settings, AlertTriangle, Clock, HardDrive, StopCircle } from 'lucide-react';
import './App.css';

const API_URL = 'http://localhost:3001/api';

function formatBytes(bytes: number, decimals = 2) {
  if (!+bytes) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
}

function formatSpeed(bytesPerSec: number) {
  return `${formatBytes(bytesPerSec)}/s`;
}

function formatTime(seconds: number) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
}

function App() {
  const [stagedTorrents, setStagedTorrents] = useState<any[]>([]);
  const [selectedTracker, setSelectedTracker] = useState('');
  const [client, setClient] = useState('qBittorrent');
  const [baseUploadSpeed, setBaseUploadSpeed] = useState(1024 * 1024); // 1 MB/s default
  const [stopAtSizeMB, setStopAtSizeMB] = useState<number | ''>('');
  const [stopAtTimeMins, setStopAtTimeMins] = useState<number | ''>('');
  const [useSequence, setUseSequence] = useState(false);
  const [sequenceLoops, setSequenceLoops] = useState<number | ''>(1);
  const [initialUploadedGB, setInitialUploadedGB] = useState<number | ''>('');
  const [initialDownloadedGB, setInitialDownloadedGB] = useState<number | ''>('');
  const [instancesCount, setInstancesCount] = useState<number>(1);
  
  const [sessions, setSessions] = useState<any[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  useEffect(() => {
    const fetchSessions = async () => {
      try {
        const res = await fetch(`${API_URL}/sessions`);
        if (res.ok) {
          const data = await res.json();
          setSessions(data);
        }
      } catch (e) {
        console.error("Failed to fetch sessions");
      }
    };
    
    fetchSessions(); // initial fetch
    const interval = setInterval(fetchSessions, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleFileUpload = async (fileList: FileList | File[]) => {
    const files = Array.from(fileList);
    const newStaged: any[] = [];
    
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (!file || !file.name.endsWith('.torrent')) {
        alert(`File ${file.name} is not a valid .torrent file`);
        continue;
      }

      const formData = new FormData();
      formData.append('torrent', file);

      try {
        const res = await fetch(`${API_URL}/torrent/parse`, {
          method: 'POST',
          body: formData
        });
        const data = await res.json();
        if (data.error) {
          alert(`Error parsing ${file.name}: ${data.error}`);
        } else {
          newStaged.push(data);
        }
      } catch (err: any) {
        alert(`Error parsing ${file.name}: ${err.message}`);
      }
    }
    
    if (newStaged.length > 0) {
      setStagedTorrents(prev => {
        const updated = [...prev, ...newStaged];
        // If there's only 1 total staged, auto-select its tracker
        if (updated.length === 1 && updated[0].trackers && updated[0].trackers.length > 0) {
          setSelectedTracker(updated[0].trackers.flat()[0]);
        }
        return updated;
      });
    }
  };

  const handleStopAll = async () => {
    try {
      const res = await fetch(`${API_URL}/session/stop-all`, { method: 'POST' });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setSessions([]);
    } catch (err: any) {
      alert(`Error stopping all sessions: ${err.message}`);
    }
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileUpload(e.dataTransfer.files);
    }
  };

  const handleStart = async () => {
    if (stagedTorrents.length === 0) return;
    
    for (const staged of stagedTorrents) {
      let trackerToUse = '';
      if (stagedTorrents.length === 1 && selectedTracker) {
        trackerToUse = selectedTracker;
      } else if (staged.trackers && staged.trackers.length > 0) {
        trackerToUse = staged.trackers.flat()[0];
      }
      
      if (!trackerToUse) {
        console.warn(`Skipping ${staged.name}: No tracker found.`);
        continue;
      }

      for (let i = 0; i < instancesCount; i++) {
        try {
          const res = await fetch(`${API_URL}/session/start`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              name: instancesCount > 1 ? `${staged.name} (Instance ${i+1})` : staged.name,
              infoHash: staged.infoHash,
              tracker: trackerToUse,
              baseUploadSpeed: baseUploadSpeed,
              client: client,
              stopAtSizeMB: stopAtSizeMB === '' ? null : stopAtSizeMB,
              stopAtTimeMins: stopAtTimeMins === '' ? null : stopAtTimeMins,
              useSequence: useSequence,
              sequenceLoops: sequenceLoops === '' ? 1 : sequenceLoops,
              initialUploadedGB: initialUploadedGB === '' ? 0 : initialUploadedGB,
              initialDownloadedGB: initialDownloadedGB === '' ? 0 : initialDownloadedGB
            })
          });
          const data = await res.json();
          if (data.error) throw new Error(data.error);
        } catch (err: any) {
          alert(`Error starting session for ${staged.name}: ${err.message}`);
        }
      }
    }
    
    // Clear staging area so user can add another
    setStagedTorrents([]);
  };

  const handleStop = async (sessionId: string) => {
    try {
      await fetch(`${API_URL}/session/stop`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId })
      });
    } catch (err: any) {
      alert("Error stopping session: " + err.message);
    }
  };

  return (
    <div className="app-container">
      <header className="header">
        <Activity size={40} className="icon-ghost" />
        <h1>GhostSeed Pro</h1>
      </header>

      <div className="dashboard">
        
        {/* Staging Area for new torrents */}
        <div className="glass-panel staging-area">
          <div style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            <h2 className="section-title">Add New Torrent</h2>
            <input 
              type="file" 
              multiple
              ref={fileInputRef} 
              onChange={(e) => e.target.files && handleFileUpload(e.target.files)} 
              style={{ display: 'none' }} 
              accept=".torrent" 
            />
            
            {stagedTorrents.length === 0 ? (
              <div 
                className={`dropzone ${isDragging ? 'active' : ''}`}
                onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={onDrop}
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload size={48} className="icon" />
                <h3>Drag & Drop .torrent(s)</h3>
                <p>or click to browse</p>
              </div>
            ) : (
              <div className="torrent-info">
                {stagedTorrents.length === 1 ? (
                  <>
                    <div className="torrent-name">{stagedTorrents[0].name || "Unknown Torrent"}</div>
                    <div className="torrent-meta">
                      Size: {formatBytes(stagedTorrents[0].length)} | Hash: {stagedTorrents[0].infoHash.substring(0, 10)}...
                    </div>
                  </>
                ) : (
                  <>
                    <div className="torrent-name">{stagedTorrents.length} Torrents Ready</div>
                    <div className="torrent-meta">
                      Total Size: {formatBytes(stagedTorrents.reduce((acc, t) => acc + (t.length || 0), 0))}
                    </div>
                  </>
                )}
                <button className="btn btn-secondary" style={{ marginTop: '1rem', padding: '0.5rem' }} onClick={() => setStagedTorrents([])}>
                  Clear
                </button>
              </div>
            )}
          </div>

          <div className="config-panel" style={{ opacity: stagedTorrents.length > 0 ? 1 : 0.5, pointerEvents: stagedTorrents.length > 0 ? 'auto' : 'none' }}>
            <div className="form-group">
              <label><Wifi size={14} style={{ marginRight: '4px', verticalAlign: 'middle' }}/> Target Tracker</label>
              {stagedTorrents.length > 1 ? (
                <div style={{ padding: '0.5rem', background: 'rgba(0,0,0,0.2)', borderRadius: '4px', color: 'var(--success)' }}>
                  Auto-selecting primary trackers for each file
                </div>
              ) : (
                <select className="form-control" value={selectedTracker} onChange={(e) => setSelectedTracker(e.target.value)}>
                  {stagedTorrents.length === 1 && stagedTorrents[0].trackers ? (
                    stagedTorrents[0].trackers.flat().map((tr: string, i: number) => (
                      <option key={i} value={tr}>{tr}</option>
                    ))
                  ) : <option value="">-</option>}
                </select>
              )}
            </div>

            <div className="form-group">
              <label><Settings size={14} style={{ marginRight: '4px', verticalAlign: 'middle' }}/> Emulated Client</label>
              <select className="form-control" value={client} onChange={(e) => setClient(e.target.value)}>
                <option value="qBittorrent">qBittorrent 4.3.5</option>
                <option value="Transmission">Transmission 3.00</option>
              </select>
            </div>

            <div className="form-group">
              <label>Base Upload Speed (+/- 15% Fluctuation)</label>
              <div className="speed-slider">
                <input 
                  type="range" 
                  min="512" 
                  max={1024 * 1024 * 50} 
                  step={1024}
                  value={baseUploadSpeed}
                  onChange={(e) => setBaseUploadSpeed(parseInt(e.target.value))}
                />
                <div className="speed-display">{formatSpeed(baseUploadSpeed)}</div>
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label><HardDrive size={14} style={{ marginRight: '4px', verticalAlign: 'middle' }}/> Auto-stop (MB)</label>
                <input type="number" className="form-control" placeholder="No limit" value={stopAtSizeMB} onChange={e => setStopAtSizeMB(e.target.value ? parseInt(e.target.value) : '')} />
              </div>
              <div className="form-group">
                <label><Clock size={14} style={{ marginRight: '4px', verticalAlign: 'middle' }}/> Auto-stop (Mins)</label>
                <input type="number" className="form-control" placeholder="No limit" value={stopAtTimeMins} onChange={e => setStopAtTimeMins(e.target.value ? parseInt(e.target.value) : '')} />
              </div>
            </div>

            <div className="form-group" style={{ background: 'rgba(0,0,0,0.2)', padding: '1rem', borderRadius: '8px' }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer', color: '#fff', textTransform: 'none', fontSize: '1rem' }}>
                <input type="checkbox" checked={useSequence} onChange={e => setUseSequence(e.target.checked)} style={{ transform: 'scale(1.2)' }} />
                Enable Human Sequence Loop (4m/2m/10m...)
              </label>
              {useSequence && (
                <div style={{ marginTop: '1rem' }}>
                  <label>Number of Loops</label>
                  <input type="number" className="form-control" min="1" value={sequenceLoops} onChange={e => setSequenceLoops(e.target.value ? parseInt(e.target.value) : '')} />
                </div>
              )}
            </div>

            <div className="form-group" style={{ background: 'rgba(0,0,0,0.2)', padding: '1rem', borderRadius: '8px' }}>
              <label style={{ marginBottom: '0.5rem' }}>Live Ratio Simulator (Optional)</label>
              <div className="form-row">
                <div className="form-group">
                  <input type="number" className="form-control" placeholder="Current Upload (GB)" value={initialUploadedGB} onChange={e => setInitialUploadedGB(e.target.value ? parseFloat(e.target.value) : '')} />
                </div>
                <div className="form-group">
                  <input type="number" className="form-control" placeholder="Current Download (GB)" value={initialDownloadedGB} onChange={e => setInitialDownloadedGB(e.target.value ? parseFloat(e.target.value) : '')} />
                </div>
              </div>
            </div>

            <div className="form-group" style={{ background: 'rgba(0,0,0,0.2)', padding: '1rem', borderRadius: '8px' }}>
              <label style={{ marginBottom: '0.5rem' }}>Multiply Sessions (Launch multiple times)</label>
              <div className="form-row">
                <input type="number" className="form-control" min="1" max="100" value={instancesCount} onChange={e => setInstancesCount(parseInt(e.target.value) || 1)} />
              </div>
            </div>

            <div className="actions">
              <button className="btn btn-start" onClick={handleStart} disabled={stagedTorrents.length === 0}>
                <Play size={20} /> START SPOOFING {stagedTorrents.length > 1 || instancesCount > 1 ? `(${stagedTorrents.length * instancesCount} Sessions)` : ''}
              </button>
            </div>
          </div>
        </div>

        <div className="active-sessions">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
            <h2>Active Sessions ({sessions.length})</h2>
            {sessions.length > 0 && (
              <button className="btn btn-secondary" style={{ background: 'var(--danger)' }} onClick={handleStopAll}>
                <StopCircle size={16} style={{ marginRight: '4px', verticalAlign: 'middle' }}/> STOP ALL SESSIONS
              </button>
            )}
          </div>
          {sessions.length === 0 ? (
            <div className="no-sessions">No active spoofing sessions.</div>
          ) : (
            <div className="sessions-grid">
              {sessions.map(session => (
                <div key={session.id} className={`glass-panel session-card ${session.status === 'stopped' ? 'stopped' : ''}`}>
                  <div className="card-header">
                    <div>
                      <div className="card-title">{session.name}</div>
                      <div className="card-tracker">{new URL(session.tracker).hostname}</div>
                    </div>
                  </div>
                  
                  <div className="status-badge" style={{ 
                    background: session.sequenceState === 'safety_pause' ? 'rgba(239, 68, 68, 0.2)' 
                              : session.sequenceState === 'pause' ? 'rgba(245, 158, 11, 0.2)' 
                              : 'rgba(16, 185, 129, 0.2)',
                    color: session.sequenceState === 'safety_pause' ? 'var(--danger)' 
                         : session.sequenceState === 'pause' ? 'var(--warning)' 
                         : 'var(--success)',
                    padding: '0.25rem 0.5rem',
                    borderRadius: '4px',
                    fontSize: '0.875rem',
                    fontWeight: 600,
                    animation: session.sequenceState === 'safety_pause' ? 'pulse 2s infinite' : 'none'
                  }}>
                    {session.sequenceState === 'safety_pause' ? '⚠️ SAFETY PAUSE (0 Leechers)' : session.sequenceState.toUpperCase()}
                  </div>

                  <div className="stats-grid">
                    <div className="stat-item">
                      <label>Time</label>
                      <span className="accent">{formatTime((Date.now() - session.startTime) / 1000)}</span>
                    </div>
                    <div className="stat-item">
                      <label>Current Speed</label>
                      <span>{session.status === 'running' ? formatSpeed(session.currentUploadSpeed) : '0 Bytes/s'}</span>
                    </div>
                    <div className="stat-item">
                      <label>Uploaded</label>
                      <span className="accent">{formatBytes(session.uploaded)}</span>
                    </div>
                    <div className="stat-item">
                      <label>Next Announce</label>
                      <span>{session.status === 'running' ? formatTime((session.nextAnnounceInMs || 0) / 1000) : '--'}</span>
                    </div>
                  </div>

                  {session.leechers !== -1 && (
                    <div style={{ display: 'flex', gap: '1rem', fontSize: '0.85rem' }}>
                      <div>Seeders: <strong>{session.seeders}</strong></div>
                      <div>Leechers: <strong>{session.leechers}</strong></div>
                    </div>
                  )}

                  {session.leechers === 0 && session.status === 'running' && (
                    <div className="leechers-warning">
                      <AlertTriangle size={16} /> 0 Leechers! High risk of detection.
                    </div>
                  )}

                  {/* Ratio Display */}
                  {(session as any).initialDownloadedGB > 0 && (
                    <div style={{ marginTop: '0.5rem', background: 'rgba(0,0,0,0.3)', padding: '0.75rem', borderRadius: '8px', textAlign: 'center' }}>
                      <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Live Tracker Ratio</div>
                      <div style={{ fontSize: '1.8rem', fontWeight: 'bold', color: 'var(--accent-color)' }}>
                        {(((session as any).initialUploadedGB * 1024 * 1024 * 1024 + session.uploaded) / ((session as any).initialDownloadedGB * 1024 * 1024 * 1024)).toFixed(3)}
                        <span style={{ fontSize: '1rem', marginLeft: '4px' }}>↗</span>
                      </div>
                    </div>
                  )}

                  {session.status === 'running' && (
                    <button className="btn btn-stop" style={{ padding: '0.75rem', fontSize: '0.9rem', marginTop: '0.5rem' }} onClick={() => handleStop(session.id)}>
                      <Square size={16} /> STOP
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;
